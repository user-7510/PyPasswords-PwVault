"""
PyPasswordsConvert.py

PyPasswords 舊版資料庫（Fernet）與 Flutter App 新版資料庫雙向轉換工具。

舊版格式：SALT(16 bytes) + Fernet token（PBKDF2-HMAC-SHA256 60萬次迭代 -> AES-128-CBC + HMAC）

新版格式（App 目前的最新格式，PWV3）：
    MAGIC("PWV3", 4 bytes) + KDF_ID(1 byte) + SALT(16 bytes) + NONCE(12 bytes) + CIPHERTEXT+TAG
    KDF_ID = 0x01 固定代表 Argon2id（19 MiB 記憶體、2 次迭代、平行度 1，OWASP 建議基準值）
    加密演算法為 AES-256-GCM

新轉舊也支援讀取更早期的 PWV2 格式（MAGIC "PWV2" + SALT + NONCE + CIPHERTEXT+TAG，
金鑰衍生為 PBKDF2），但本工具的「舊轉新」一律輸出最新的 PWV3。

依賴：cryptography 套件（需支援 Argon2id KDF，本機已驗證可用）。
不連網、不上傳任何資料。

用法：
    python3 PyPasswordsConvert.py           互動式轉換（舊轉新 / 新轉舊）
    python3 PyPasswordsConvert.py --selftest 離線自我測試，驗證雙向格式一致性，不需要真實資料庫
"""

import os
import sys
import json
import base64
import getpass
import hashlib
import secrets
import argparse
import tempfile
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import hashes

OLD_SALT_SIZE = 16
NEW_SALT_SIZE = 16
NEW_NONCE_SIZE = 12
KDF_ITERATIONS = 600_000  # PBKDF2，僅用於舊版與 PWV2 讀取

NEW_MAGIC_V2 = b"PWV2"
NEW_MAGIC_V3 = b"PWV3"
NEW_V3_HEADER_SIZE = len(NEW_MAGIC_V3) + 1 + NEW_SALT_SIZE + NEW_NONCE_SIZE
NEW_V2_HEADER_SIZE = len(NEW_MAGIC_V2) + NEW_SALT_SIZE + NEW_NONCE_SIZE

ARGON2_MEMORY_KIB = 19456  # 19 MiB，OWASP 建議基準值
ARGON2_ITERATIONS = 2
ARGON2_PARALLELISM = 1
ARGON2_HASH_LEN = 32
KDF_ID_ARGON2ID = 0x01


# ---------------------------------------------------------------------------
# 金鑰衍生
# ---------------------------------------------------------------------------

def deriveOldFernetKey(masterPassword: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=KDF_ITERATIONS,
    )
    return base64.urlsafe_b64encode(kdf.derive(masterPassword.encode("utf-8")))


def deriveNewAesKeyPbkdf2(masterPassword: str, salt: bytes) -> bytes:
    """僅用於讀取舊版 PWV2 檔案。"""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=KDF_ITERATIONS,
    )
    return kdf.derive(masterPassword.encode("utf-8"))


def deriveNewAesKeyArgon2id(masterPassword: str, salt: bytes) -> bytes:
    """PWV3 格式使用，須與 Dart 端 crypto_service.dart 的
    Argon2id(memory: 19456, iterations: 2, parallelism: 1, hashLength: 32) 完全對應。"""
    kdf = Argon2id(
        salt=salt,
        length=ARGON2_HASH_LEN,
        iterations=ARGON2_ITERATIONS,
        lanes=ARGON2_PARALLELISM,
        memory_cost=ARGON2_MEMORY_KIB,
    )
    return kdf.derive(masterPassword.encode("utf-8"))


# ---------------------------------------------------------------------------
# 檔案讀寫共用工具
# ---------------------------------------------------------------------------

def writeAtomic(path: Path, data: bytes) -> None:
    tmpPath = path.with_suffix(path.suffix + ".tmp")
    tmpPath.write_bytes(data)
    os.chmod(tmpPath, 0o600)
    tmpPath.replace(path)
    os.chmod(path, 0o600)


def writeChecksum(path: Path) -> Path:
    checksum = hashlib.sha256(path.read_bytes()).hexdigest()
    checksumPath = path.with_name(path.name + ".sha256")
    checksumPath.write_text(checksum)
    os.chmod(checksumPath, 0o600)
    return checksumPath


def normalizeRecords(data) -> list:
    if isinstance(data, dict) and isinstance(data.get("records"), list):
        return data["records"]
    return []


# ---------------------------------------------------------------------------
# 舊版（Fernet，PyPasswords.py 終端機版）讀寫
# ---------------------------------------------------------------------------

def loadOldVault(oldPath: Path, masterPassword: str) -> dict:
    rawData = oldPath.read_bytes()
    if len(rawData) < OLD_SALT_SIZE:
        raise ValueError("舊版資料庫檔案格式錯誤")
    salt, token = rawData[:OLD_SALT_SIZE], rawData[OLD_SALT_SIZE:]
    key = deriveOldFernetKey(masterPassword, salt)
    fernet = Fernet(key)
    try:
        plaintext = fernet.decrypt(token)
    except InvalidToken:
        raise ValueError("主碼錯誤，或舊版資料庫已損毀")
    return json.loads(plaintext.decode("utf-8"))


def writeOldVault(oldPath: Path, masterPassword: str, payload: dict) -> None:
    salt = secrets.token_bytes(OLD_SALT_SIZE)
    key = deriveOldFernetKey(masterPassword, salt)
    fernet = Fernet(key)
    token = fernet.encrypt(json.dumps(payload).encode("utf-8"))
    writeAtomic(oldPath, salt + token)


# ---------------------------------------------------------------------------
# 新版讀寫（讀取支援 PWV2/PWV3，寫入一律輸出最新的 PWV3）
# ---------------------------------------------------------------------------

def loadNewVault(newPath: Path, masterPassword: str) -> dict:
    rawData = newPath.read_bytes()

    if rawData[:4] == NEW_MAGIC_V3:
        if len(rawData) < NEW_V3_HEADER_SIZE:
            raise ValueError("新版（PWV3）資料庫檔案格式錯誤")
        kdfId = rawData[4]
        if kdfId != KDF_ID_ARGON2ID:
            raise ValueError(f"不支援的 KDF 版本代碼: {kdfId}")
        offset = 5
        salt = rawData[offset:offset + NEW_SALT_SIZE]
        offset += NEW_SALT_SIZE
        nonce = rawData[offset:offset + NEW_NONCE_SIZE]
        offset += NEW_NONCE_SIZE
        cipherTextWithTag = rawData[offset:]
        key = deriveNewAesKeyArgon2id(masterPassword, salt)
    elif rawData[:4] == NEW_MAGIC_V2:
        if len(rawData) < NEW_V2_HEADER_SIZE:
            raise ValueError("新版（PWV2）資料庫檔案格式錯誤")
        offset = 4
        salt = rawData[offset:offset + NEW_SALT_SIZE]
        offset += NEW_SALT_SIZE
        nonce = rawData[offset:offset + NEW_NONCE_SIZE]
        offset += NEW_NONCE_SIZE
        cipherTextWithTag = rawData[offset:]
        key = deriveNewAesKeyPbkdf2(masterPassword, salt)
    else:
        raise ValueError("新版資料庫檔案格式錯誤（MAGIC 不符，非 PWV2 亦非 PWV3）")

    aesgcm = AESGCM(key)
    try:
        plaintext = aesgcm.decrypt(nonce, bytes(cipherTextWithTag), None)
    except InvalidTag:
        raise ValueError("主碼錯誤，或新版資料庫已損毀")
    return json.loads(plaintext.decode("utf-8"))


def writeNewVault(newPath: Path, masterPassword: str, payload: dict) -> None:
    """一律輸出最新的 PWV3（Argon2id）格式。"""
    salt = secrets.token_bytes(NEW_SALT_SIZE)
    nonce = secrets.token_bytes(NEW_NONCE_SIZE)
    key = deriveNewAesKeyArgon2id(masterPassword, salt)
    aesgcm = AESGCM(key)
    plaintext = json.dumps(payload).encode("utf-8")
    cipherTextWithTag = aesgcm.encrypt(nonce, plaintext, None)
    fileBytes = NEW_MAGIC_V3 + bytes([KDF_ID_ARGON2ID]) + salt + nonce + cipherTextWithTag
    writeAtomic(newPath, fileBytes)


# ---------------------------------------------------------------------------
# 互動式轉換流程
# ---------------------------------------------------------------------------

def promptNewMasterPassword(currentPassword: str) -> str:
    changePassword = input("是否要在轉換後改用不同的主碼？(y/N): ").strip().lower()
    if changePassword != "y":
        return currentPassword
    newPass1 = getpass.getpass("設定新主碼: ")
    newPass2 = getpass.getpass("再次輸入新主碼確認: ")
    if newPass1 != newPass2:
        raise ValueError("兩次輸入不一致")
    return newPass1


def convertOldToNew(oldPath: Path, outputDir: Path) -> None:
    print(f"\n=== 轉換（舊轉新，輸出 PWV3/Argon2id） {oldPath.name} ===")
    masterPassword = getpass.getpass("輸入此設定檔的主碼: ")
    try:
        oldData = loadOldVault(oldPath, masterPassword)
    except ValueError as e:
        print(f"錯誤：{e}")
        return
    records = normalizeRecords(oldData)
    print(f"成功解密，共 {len(records)} 筆紀錄")

    try:
        newMasterPassword = promptNewMasterPassword(masterPassword)
    except ValueError as e:
        print(f"錯誤：{e}，已取消此檔案轉換")
        return

    print("正在以 Argon2id 衍生金鑰（19 MiB 記憶體），可能需要數百毫秒到數秒...")
    outputDir.mkdir(parents=True, exist_ok=True)
    newPath = outputDir / f"{oldPath.stem}.pwv2"
    writeNewVault(newPath, newMasterPassword, {"records": records})
    checksumPath = writeChecksum(newPath)
    print(f"已輸出新版檔案（PWV3）: {newPath}")
    print(f"對應 checksum: {checksumPath}")
    print("提醒：可將此檔案透過 App「匯出／匯入備份」功能匯入。")


def convertNewToOld(newPath: Path, outputDir: Path) -> None:
    print(f"\n=== 轉換（新轉舊） {newPath.name} ===")
    masterPassword = getpass.getpass("輸入此設定檔的主碼: ")
    try:
        newData = loadNewVault(newPath, masterPassword)
    except ValueError as e:
        print(f"錯誤：{e}")
        return
    records = normalizeRecords(newData)
    print(f"成功解密，共 {len(records)} 筆紀錄")

    try:
        oldMasterPassword = promptNewMasterPassword(masterPassword)
    except ValueError as e:
        print(f"錯誤：{e}，已取消此檔案轉換")
        return

    outputDir.mkdir(parents=True, exist_ok=True)
    oldPath = outputDir / f"{newPath.stem}.bin"
    writeOldVault(oldPath, oldMasterPassword, {"records": records})
    print(f"已輸出舊版檔案: {oldPath}")
    print("提醒：此檔案可放回 ~/.pwvault/ 供 PyPasswords.py 讀取。")


def runInteractiveConversion(direction: str) -> None:
    if direction == "1":
        defaultDir = Path.home() / ".pwvault"
        pattern = "*.bin"
        convertFn = convertOldToNew
        label = "舊版（.bin）"
    else:
        defaultDir = Path.cwd()
        pattern = "*.pwv2"
        convertFn = convertNewToOld
        label = "新版（.pwv2，PWV2 或 PWV3 皆可）"

    sourceDirRaw = input(f"輸入{label}設定檔所在資料夾（預設 {defaultDir}）: ").strip()
    sourceDir = Path(sourceDirRaw) if sourceDirRaw else defaultDir
    if not sourceDir.exists():
        print(f"找不到資料夾: {sourceDir}")
        sys.exit(1)

    sourceFiles = sorted(sourceDir.glob(pattern))
    if not sourceFiles:
        print(f"找不到任何 {pattern} 檔案")
        sys.exit(1)

    print(f"找到以下{label}設定檔:")
    for i, f in enumerate(sourceFiles, start=1):
        print(f"  {i}. {f.stem}")

    outputDirRaw = input("輸入輸出資料夾（預設為 ./converted）: ").strip()
    outputDir = Path(outputDirRaw) if outputDirRaw else Path.cwd() / "converted"

    selection = input("輸入要轉換的編號（逗號分隔，或輸入 all 全部轉換）: ").strip()
    if selection.lower() == "all":
        targets = sourceFiles
    else:
        targets = []
        for part in selection.split(","):
            part = part.strip()
            if part.isdigit() and 1 <= int(part) <= len(sourceFiles):
                targets.append(sourceFiles[int(part) - 1])

    if not targets:
        print("未選擇任何檔案")
        sys.exit(1)

    for path in targets:
        convertFn(path, outputDir)

    print("\n全部轉換作業完成。")


def main() -> None:
    print("PyPasswords 資料庫格式轉換工具（支援舊轉新、新轉舊）")
    print("舊轉新固定輸出最新的 PWV3（Argon2id）格式。")
    print("本工具完全離線執行，不會連網、不會上傳任何資料。\n")
    print("1. 舊版（.bin）轉新版（PWV3）")
    print("2. 新版（.pwv2，PWV2 或 PWV3）轉舊版（.bin）")
    direction = input("請選擇方向 (1/2): ").strip()
    if direction not in ("1", "2"):
        print("無效選項")
        sys.exit(1)
    runInteractiveConversion(direction)


# ---------------------------------------------------------------------------
# 離線自我測試（不需要真實資料庫，用假資料驗證格式往返一致性）
# ---------------------------------------------------------------------------

def runSelfTest() -> None:
    dummyPassword = "test-master-password-12345"
    otherPassword = "changed-master-password-67890"
    dummyPayload = {
        "records": [
            {
                "id": "abc123",
                "accountType": "email",
                "accountName": "test@example.com",
                "password": "S0m3P@ssw0rd!",
                "linkedAccount": "",
                "name": "測試帳號",
                "notes": ["這是一筆自我測試用的假資料"],
            }
        ]
    }

    with tempfile.TemporaryDirectory() as tmpDirName:
        tmpDir = Path(tmpDirName)

        print("[1/5] 測試舊版格式自身往返（寫入 -> 讀取）...")
        oldPath = tmpDir / "selftest.bin"
        writeOldVault(oldPath, dummyPassword, dummyPayload)
        oldResult = loadOldVault(oldPath, dummyPassword)
        assert oldResult == dummyPayload, "舊版格式往返後資料不一致"
        print("    通過")

        print("[2/5] 測試新版 PWV3（Argon2id）格式自身往返...")
        newPath = tmpDir / "selftest.pwv2"
        writeNewVault(newPath, dummyPassword, dummyPayload)
        assert newPath.read_bytes()[:4] == NEW_MAGIC_V3, "writeNewVault 未輸出 PWV3 格式"
        newResult = loadNewVault(newPath, dummyPassword)
        assert newResult == dummyPayload, "PWV3 格式往返後資料不一致"
        print("    通過")

        print("[3/5] 測試向下相容讀取舊版 PWV2（PBKDF2）格式...")
        legacySalt = secrets.token_bytes(NEW_SALT_SIZE)
        legacyNonce = secrets.token_bytes(NEW_NONCE_SIZE)
        legacyKey = deriveNewAesKeyPbkdf2(dummyPassword, legacySalt)
        legacyCipher = AESGCM(legacyKey).encrypt(
            legacyNonce, json.dumps(dummyPayload).encode("utf-8"), None
        )
        legacyPath = tmpDir / "selftest_legacy.pwv2"
        legacyPath.write_bytes(NEW_MAGIC_V2 + legacySalt + legacyNonce + legacyCipher)
        legacyResult = loadNewVault(legacyPath, dummyPassword)
        assert legacyResult == dummyPayload, "PWV2 向下相容讀取後資料不一致"
        print("    通過")

        print("[4/5] 測試舊轉新（含更換主碼，輸出 PWV3）再轉回舊版...")
        loadedOld = loadOldVault(oldPath, dummyPassword)
        convertedNewPath = tmpDir / "selftest_converted.pwv2"
        writeNewVault(convertedNewPath, otherPassword, {"records": normalizeRecords(loadedOld)})
        loadedNew = loadNewVault(convertedNewPath, otherPassword)
        convertedOldPath = tmpDir / "selftest_converted.bin"
        writeOldVault(convertedOldPath, dummyPassword, {"records": normalizeRecords(loadedNew)})
        finalResult = loadOldVault(convertedOldPath, dummyPassword)
        assert finalResult == dummyPayload, "舊轉新再轉舊之後資料不一致"
        print("    通過")

        print("[5/5] 測試錯誤主碼會被正確拒絕...")
        try:
            loadOldVault(oldPath, "wrong-password")
            raise AssertionError("舊版格式未能偵測錯誤主碼")
        except ValueError:
            pass
        try:
            loadNewVault(newPath, "wrong-password")
            raise AssertionError("PWV3 格式未能偵測錯誤主碼")
        except ValueError:
            pass
        print("    通過")

    print("\n全部自我測試通過。")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PyPasswords 資料庫雙向轉換工具")
    parser.add_argument("--selftest", action="store_true", help="執行離線自我測試，不需要真實資料庫")
    args = parser.parse_args()

    try:
        if args.selftest:
            runSelfTest()
        else:
            main()
    except (KeyboardInterrupt, EOFError):
        print("\n已中止")
        sys.exit(0)
