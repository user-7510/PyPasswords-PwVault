import os
import re
import sys
import csv
import json
import base64
import secrets
import string
import getpass
import hashlib
import argparse
from pathlib import Path
from typing import Optional, Tuple, List, Dict, Any

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

VAULT_DIR = Path.home() / ".pwvault"
SALT_SIZE = 16
KDF_ITERATIONS = 600_000
SYMBOLS = "!@#$%^&*()-_=+[]{}"
PROFILE_NAME_PATTERN = re.compile(r"[\w\-\u4e00-\u9fff]+")

COMMON_WEAK_PASSWORDS = {
    "password", "123456", "12345678", "qwerty", "111111",
    "123456789", "abc123", "password1", "iloveyou", "admin",
    "letmein", "welcome", "monkey", "dragon", "master",
    "000000", "1234567", "sunshine", "princess", "football",
}


def clearScreen() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def wipeBytearray(data: bytearray) -> None:
    for i in range(len(data)):
        data[i] = 0


def ensureVaultDir() -> None:
    VAULT_DIR.mkdir(mode=0o700, exist_ok=True)
    os.chmod(VAULT_DIR, 0o700)


def sanitizeProfileName(name: str) -> Optional[str]:
    name = name.strip()
    if not name:
        return None
    if not PROFILE_NAME_PATTERN.fullmatch(name):
        return None
    return name


def listProfiles() -> List[str]:
    if not VAULT_DIR.exists():
        return []
    return sorted(p.stem for p in VAULT_DIR.glob("*.bin"))


def vaultPath(profile: str) -> Path:
    return VAULT_DIR / f"{profile}.bin"


def selectProfile() -> Optional[str]:
    ensureVaultDir()
    profiles = listProfiles()
    if profiles:
        print("現有設定檔: " + ", ".join(profiles))
    else:
        print("目前尚無任何設定檔")
    name = input("輸入設定檔名稱（新名稱將建立新設定檔）: ").strip()
    sanitized = sanitizeProfileName(name)
    if sanitized is None:
        print("設定檔名稱不合法，僅允許字母、數字、底線、連字號、中文字元")
        return None
    return sanitized


def deriveKey(masterPassword: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=KDF_ITERATIONS,
    )
    keyBytes = bytearray(kdf.derive(masterPassword.encode("utf-8")))
    encodedKey = base64.urlsafe_b64encode(bytes(keyBytes))
    wipeBytearray(keyBytes)
    return encodedKey


def generatePassword(length: int = 20) -> str:
    if length < 12:
        raise ValueError("長度過短，不建議低於12")
    alphabet = string.ascii_letters + string.digits + SYMBOLS
    while True:
        pwd = "".join(secrets.choice(alphabet) for _ in range(length))
        if (any(c.islower() for c in pwd)
                and any(c.isupper() for c in pwd)
                and any(c.isdigit() for c in pwd)
                and any(c in SYMBOLS for c in pwd)):
            return pwd


def isWeakPassword(password: str) -> Optional[str]:
    lowered = password.lower()
    if lowered in COMMON_WEAK_PASSWORDS:
        return "此密碼為常見弱密碼清單中的項目"
    if len(password) < 8:
        return "長度低於8字元"
    if password.isdigit():
        return "全部由數字組成"
    if password.isalpha() and password.islower():
        return "全部由小寫字母組成"
    if len(set(password)) <= 3:
        return "字元重複性過高，多樣性不足"
    return None


def assessPasswordStrength(password: str) -> str:
    score = 0
    if len(password) >= 12:
        score += 1
    if len(password) >= 16:
        score += 1
    if any(c.islower() for c in password) and any(c.isupper() for c in password):
        score += 1
    if any(c.isdigit() for c in password):
        score += 1
    if any(c in SYMBOLS for c in password):
        score += 1
    if len(password) > 0 and len(set(password)) < len(password) * 0.6:
        score -= 1
    if score <= 1:
        return "弱"
    if score <= 3:
        return "中"
    return "強"


def newRecordId() -> str:
    return secrets.token_hex(4)


def normalizeVaultData(data: Any) -> List[Dict[str, Any]]:
    if isinstance(data, dict) and isinstance(data.get("records"), list):
        return data["records"]
    if isinstance(data, dict):
        migrated = []
        for key, value in data.items():
            if isinstance(value, str):
                migrated.append({
                    "id": newRecordId(),
                    "accountType": "",
                    "accountName": key,
                    "password": value,
                    "linkedAccount": "",
                    "name": "",
                    "notes": [],
                })
        return migrated
    return []


def computeChecksum(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def loadVaultRaw(path: Path) -> Optional[Tuple[bytes, bytes]]:
    try:
        data = path.read_bytes()
    except OSError as e:
        print(f"讀取資料庫失敗: {e}")
        return None
    if len(data) < SALT_SIZE:
        print("資料庫檔案格式錯誤")
        return None
    return data[:SALT_SIZE], data[SALT_SIZE:]


def saveVaultRaw(path: Path, salt: bytes, token: bytes) -> bool:
    tmpPath = path.with_suffix(".tmp")
    try:
        tmpPath.write_bytes(salt + token)
        os.chmod(tmpPath, 0o600)
        tmpPath.replace(path)
        os.chmod(path, 0o600)
    except OSError as e:
        print(f"寫入資料庫失敗: {e}")
        return False
    return True


def setupMasterPassword(path: Path, weakCheck: bool = False) -> None:
    if path.exists():
        confirm = input("此設定檔主碼已存在，重設將清空所有紀錄，是否繼續？(y/N): ")
        if confirm.lower() != "y":
            print("已取消")
            return
    master1 = getpass.getpass("設定主碼: ")
    master2 = getpass.getpass("再次輸入主碼確認: ")
    if master1 != master2:
        print("兩次輸入不一致")
        return
    if weakCheck:
        weakReason = isWeakPassword(master1)
        if weakReason:
            print(f"警告：{weakReason}")
            proceed = input("仍要使用此主碼嗎？(y/N): ").strip().lower()
            if proceed != "y":
                print("已取消，請重新設定")
                return
    print("警告：主碼遺失將導致此設定檔所有紀錄永久無法復原，本程式不提供任何救援機制。")
    ensureVaultDir()
    salt = secrets.token_bytes(SALT_SIZE)
    key = deriveKey(master1, salt)
    fernet = Fernet(key)
    emptyData = json.dumps({"records": []}).encode("utf-8")
    token = fernet.encrypt(emptyData)
    if saveVaultRaw(path, salt, token):
        print(f"主碼設定完成，資料庫已建立於 {path}")


def unlockVault(path: Path) -> Optional[Tuple[bytes, List[Dict[str, Any]], str]]:
    if not path.exists():
        print("此設定檔尚未設定主碼，請先執行設定主碼")
        return None
    raw = loadVaultRaw(path)
    if raw is None:
        return None
    salt, token = raw
    master = getpass.getpass("輸入主碼: ")
    key = deriveKey(master, salt)
    fernet = Fernet(key)
    try:
        data = fernet.decrypt(token)
    except InvalidToken:
        print("主碼錯誤，或資料已損毀")
        return None
    records = normalizeVaultData(json.loads(data.decode("utf-8")))
    return salt, records, master


def persistRecords(path: Path, salt: bytes, master: str, records: List[Dict[str, Any]]) -> bool:
    key = deriveKey(master, salt)
    fernet = Fernet(key)
    token = fernet.encrypt(json.dumps({"records": records}).encode("utf-8"))
    return saveVaultRaw(path, salt, token)


def promptNotes() -> List[str]:
    notes = []
    while True:
        note = input("新增備註（留空結束）: ").strip()
        if not note:
            break
        notes.append(note)
    return notes


def printRecord(record: Dict[str, Any]) -> None:
    print("-" * 40)
    print(f"帳戶類型: {record.get('accountType', '')}")
    print(f"帳號名稱: {record.get('accountName', '')}")
    print(f"密碼: {record.get('password', '')}")
    print(f"連結帳戶: {record.get('linkedAccount', '')}")
    print(f"姓名: {record.get('name', '')}")
    notes = record.get("notes", [])
    if notes:
        print("備註:")
        for note in notes:
            print(f"  - {note}")
    print("-" * 40)


def addRecord(path: Path) -> None:
    unlocked = unlockVault(path)
    if unlocked is None:
        return
    salt, records, master = unlocked
    accountType = input("帳戶類型: ").strip()
    accountName = input("帳號名稱: ").strip()
    choice = input("自動生成密碼？(Y/n): ").strip().lower()
    if choice == "n":
        password = getpass.getpass("輸入密碼: ")
        strength = assessPasswordStrength(password)
        print(f"密碼強度評估: {strength}")
        if strength == "弱":
            print("建議改用自動生成的密碼")
    else:
        lengthRaw = input("密碼長度 (預設20): ").strip()
        length = int(lengthRaw) if lengthRaw.isdigit() else 20
        password = generatePassword(length)
        print(f"已生成密碼（僅顯示一次）: {password}")
    linkedAccount = input("連結帳戶（可留空）: ").strip()
    personName = input("姓名（可留空）: ").strip()
    notes = promptNotes()
    record = {
        "id": newRecordId(),
        "accountType": accountType,
        "accountName": accountName,
        "password": password,
        "linkedAccount": linkedAccount,
        "name": personName,
        "notes": notes,
    }
    del password
    records.append(record)
    saved = persistRecords(path, salt, master, records)
    del records
    if saved:
        print(f"帳號 {accountName} 已加密紀錄")


def findMatches(records: List[Dict[str, Any]], keyword: str) -> List[Dict[str, Any]]:
    keywordLower = keyword.lower()
    return [r for r in records if keywordLower in r.get("accountName", "").lower()]


def printNumberedMatches(matches: List[Dict[str, Any]]) -> None:
    for idx, record in enumerate(matches, start=1):
        print(f"{idx}. [{record.get('accountType', '')}] {record.get('accountName', '')} ({record.get('name', '')})")


def chooseFromMatches(matches: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if len(matches) == 1:
        return matches[0]
    print(f"找到 {len(matches)} 筆符合的紀錄:")
    printNumberedMatches(matches)
    choiceRaw = input("選擇編號: ").strip()
    if not choiceRaw.isdigit() or not (1 <= int(choiceRaw) <= len(matches)):
        print("輸入不合法")
        return None
    return matches[int(choiceRaw) - 1]


def chooseMultipleFromMatches(matches: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    print(f"找到 {len(matches)} 筆符合的紀錄:")
    printNumberedMatches(matches)
    choiceRaw = input("選擇編號（可用逗號分隔多個，或輸入 all 選擇全部）: ").strip()
    if choiceRaw.lower() == "all":
        return list(matches)
    selected = []
    for part in choiceRaw.split(","):
        part = part.strip()
        if not part:
            continue
        if not part.isdigit() or not (1 <= int(part) <= len(matches)):
            print(f"忽略不合法的編號: {part}")
            continue
        selected.append(matches[int(part) - 1])
    return selected


def queryPasswords(path: Path) -> None:
    unlocked = unlockVault(path)
    if unlocked is None:
        return
    _, records, _ = unlocked
    if not records:
        print("目前沒有任何紀錄")
        return
    keyword = input("輸入要查詢的帳號名稱（可輸入部分文字）: ").strip()
    matches = findMatches(records, keyword)
    del records
    if not matches:
        print("找不到符合的紀錄")
        return
    record = chooseFromMatches(matches)
    del matches
    if record is None:
        return
    printRecord(record)
    del record
    clearNow = input("按 Enter 清除畫面（輸入其他任意字元跳過）: ").strip()
    if clearNow == "":
        clearScreen()


def listRecords(path: Path) -> None:
    unlocked = unlockVault(path)
    if unlocked is None:
        return
    _, records, _ = unlocked
    if not records:
        print("目前沒有任何紀錄")
        return
    for idx, record in enumerate(records, start=1):
        print(f"{idx}. [{record.get('accountType', '')}] {record.get('accountName', '')} ({record.get('name', '')})")
    del records


def deleteRecord(path: Path) -> None:
    unlocked = unlockVault(path)
    if unlocked is None:
        return
    salt, records, master = unlocked
    if not records:
        print("目前沒有任何紀錄")
        return
    keyword = input("輸入要刪除的帳號名稱（可輸入部分文字，留空列出全部）: ").strip()
    matches = findMatches(records, keyword) if keyword else list(records)
    if not matches:
        print("找不到符合的紀錄")
        return
    targets = chooseMultipleFromMatches(matches)
    if not targets:
        print("未選擇任何項目")
        return
    print("即將刪除以下紀錄:")
    for target in targets:
        printRecord(target)
    confirm = input(f"確定刪除以上 {len(targets)} 筆紀錄嗎？(y/N): ").strip().lower()
    if confirm != "y":
        print("已取消")
        return
    targetIds = {target.get("id") for target in targets}
    records = [r for r in records if r.get("id") not in targetIds]
    saved = persistRecords(path, salt, master, records)
    del records
    if saved:
        print(f"已刪除 {len(targetIds)} 筆紀錄")


def editNotes(record: Dict[str, Any]) -> None:
    notes = record.get("notes", [])
    while True:
        print("目前備註:")
        if not notes:
            print("  (無)")
        else:
            for idx, note in enumerate(notes, start=1):
                print(f"  {idx}. {note}")
        subMenu = """
1. 新增備註
2. 刪除備註
3. 完成
"""
        print(subMenu)
        subChoice = input("選擇: ").strip()
        if subChoice == "1":
            newNote = input("輸入新備註: ").strip()
            if newNote:
                notes.append(newNote)
        elif subChoice == "2":
            if not notes:
                print("目前沒有備註可刪除")
                continue
            idxRaw = input("輸入要刪除的備註編號: ").strip()
            if idxRaw.isdigit() and 1 <= int(idxRaw) <= len(notes):
                notes.pop(int(idxRaw) - 1)
            else:
                print("輸入不合法")
        elif subChoice == "3":
            break
        else:
            print("無效選項")
    record["notes"] = notes


def editRecord(path: Path) -> None:
    unlocked = unlockVault(path)
    if unlocked is None:
        return
    salt, records, master = unlocked
    if not records:
        print("目前沒有任何紀錄")
        return
    keyword = input("輸入要編輯的帳號名稱（可輸入部分文字，留空列出全部）: ").strip()
    matches = findMatches(records, keyword) if keyword else list(records)
    if not matches:
        print("找不到符合的紀錄")
        return
    target = chooseFromMatches(matches)
    if target is None:
        return
    printRecord(target)
    fieldMenu = """
選擇要編輯的欄位:
1. 帳戶類型
2. 帳號名稱
3. 密碼
4. 連結帳戶
5. 姓名
6. 備註
0. 取消
"""
    print(fieldMenu)
    fieldChoice = input("選擇: ").strip()
    if fieldChoice == "1":
        target["accountType"] = input("輸入新的帳戶類型: ").strip()
    elif fieldChoice == "2":
        target["accountName"] = input("輸入新的帳號名稱: ").strip()
    elif fieldChoice == "3":
        choice = input("自動生成新密碼？(Y/n): ").strip().lower()
        if choice == "n":
            newPassword = getpass.getpass("輸入新密碼: ")
            strength = assessPasswordStrength(newPassword)
            print(f"密碼強度評估: {strength}")
        else:
            lengthRaw = input("密碼長度 (預設20): ").strip()
            length = int(lengthRaw) if lengthRaw.isdigit() else 20
            newPassword = generatePassword(length)
            print(f"已生成密碼（僅顯示一次）: {newPassword}")
        target["password"] = newPassword
        del newPassword
    elif fieldChoice == "4":
        target["linkedAccount"] = input("輸入新的連結帳戶: ").strip()
    elif fieldChoice == "5":
        target["name"] = input("輸入新的姓名: ").strip()
    elif fieldChoice == "6":
        editNotes(target)
    elif fieldChoice == "0":
        print("已取消")
        return
    else:
        print("無效選項")
        return
    saved = persistRecords(path, salt, master, records)
    del records
    if saved:
        print("已更新該筆紀錄")


def exportBackup(path: Path) -> None:
    if not path.exists():
        print("此設定檔尚未建立資料庫，無法匯出")
        return
    destPath = input("輸入備份儲存路徑 (例如 /path/to/backup.bin): ").strip()
    if not destPath:
        print("路徑不可為空")
        return
    try:
        data = path.read_bytes()
    except OSError as e:
        print(f"讀取資料庫失敗: {e}")
        return
    checksum = computeChecksum(data)
    destFile = Path(destPath)
    checksumFile = destFile.with_name(destFile.name + ".sha256")
    try:
        destFile.write_bytes(data)
        os.chmod(destFile, 0o600)
        checksumFile.write_text(checksum)
        os.chmod(checksumFile, 0o600)
    except OSError as e:
        print(f"寫入備份失敗: {e}")
        return
    print(f"已匯出備份至 {destFile}，checksum 已存於 {checksumFile}")


def importBackup(path: Path) -> None:
    srcPath = input("輸入備份檔案路徑: ").strip()
    srcFile = Path(srcPath)
    if not srcFile.exists():
        print("備份檔案不存在")
        return
    checksumFile = srcFile.with_name(srcFile.name + ".sha256")
    try:
        data = srcFile.read_bytes()
    except OSError as e:
        print(f"讀取備份失敗: {e}")
        return
    if checksumFile.exists():
        try:
            expected = checksumFile.read_text().strip()
        except OSError as e:
            print(f"讀取checksum檔案失敗: {e}")
            return
        if expected != computeChecksum(data):
            print("警告：checksum 不符，備份檔案可能已損毀或被竄改，已中止匯入")
            return
    else:
        print("警告：找不到對應的 .sha256 checksum 檔案，無法驗證完整性")
        proceed = input("仍要繼續匯入嗎？(y/N): ").strip().lower()
        if proceed != "y":
            print("已取消")
            return
    if path.exists():
        confirm = input("匯入將覆蓋此設定檔現有資料庫，是否繼續？(y/N): ").strip().lower()
        if confirm != "y":
            print("已取消")
            return
    ensureVaultDir()
    try:
        path.write_bytes(data)
        os.chmod(path, 0o600)
    except OSError as e:
        print(f"寫入資料庫失敗: {e}")
        return
    print("匯入完成")


def collectNotesFromRow(row: Dict[str, str], noteColumns: List[str]) -> List[str]:
    notes = []
    for column in noteColumns:
        value = (row.get(column) or "").strip()
        if not value:
            continue
        parts = re.split(r"[;；]", value)
        notes.extend(part.strip() for part in parts if part.strip())
    return notes


def importCsv(path: Path) -> None:
    unlocked = unlockVault(path)
    if unlocked is None:
        return
    salt, records, master = unlocked
    print("CSV欄位需包含：帳戶類型,帳號名稱,密碼,連結帳戶,姓名,備註")
    print("備註欄可重複多欄（例如 備註1、備註2），同一欄內亦可用 ; 或 ； 分隔多筆備註")
    csvPath = input("輸入CSV檔案路徑: ").strip()
    csvFile = Path(csvPath)
    if not csvFile.exists():
        print("CSV檔案不存在")
        return
    importedCount = 0
    try:
        with csvFile.open(newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            fieldnames = reader.fieldnames or []
            noteColumns = [h for h in fieldnames if h and "備註" in h]
            for row in reader:
                record = {
                    "id": newRecordId(),
                    "accountType": (row.get("帳戶類型") or "").strip(),
                    "accountName": (row.get("帳號名稱") or "").strip(),
                    "password": (row.get("密碼") or "").strip(),
                    "linkedAccount": (row.get("連結帳戶") or "").strip(),
                    "name": (row.get("姓名") or "").strip(),
                    "notes": collectNotesFromRow(row, noteColumns),
                }
                records.append(record)
                importedCount += 1
    except OSError as e:
        print(f"讀取CSV失敗: {e}")
        return
    except csv.Error as e:
        print(f"CSV格式錯誤: {e}")
        return
    saved = persistRecords(path, salt, master, records)
    del records
    if saved:
        print(f"已匯入 {importedCount} 筆紀錄")
        print("提醒：來源CSV檔案本身為明文，匯入完成後建議自行安全刪除該檔案")


def requireProfile(currentProfile: Optional[str]) -> Optional[str]:
    if currentProfile is not None:
        return currentProfile
    print("尚未選擇設定檔")
    return selectProfile()


def mainMenu(weakCheck: bool = False) -> None:
    ensureVaultDir()
    currentProfile: Optional[str] = None
    menuText = """
1. 生成密碼
2. 紀錄密碼（新增）
3. 設定主碼
4. 查詢密碼
5. 列出所有紀錄（不顯示密碼）
6. 編輯紀錄
7. 刪除紀錄
8. 匯出備份
9. 匯入備份
10. 匯入CSV
11. 切換設定檔
0. 離開
"""
    while True:
        print(f"目前設定檔: {currentProfile if currentProfile else '未選擇'}")
        print(menuText)
        choice = input("選擇功能: ").strip()
        if choice == "1":
            lengthRaw = input("密碼長度 (預設20): ").strip()
            length = int(lengthRaw) if lengthRaw.isdigit() else 20
            print(f"生成密碼: {generatePassword(length)}")
        elif choice == "2":
            currentProfile = requireProfile(currentProfile)
            if currentProfile:
                addRecord(vaultPath(currentProfile))
        elif choice == "3":
            currentProfile = requireProfile(currentProfile)
            if currentProfile:
                setupMasterPassword(vaultPath(currentProfile), weakCheck=weakCheck)
        elif choice == "4":
            currentProfile = requireProfile(currentProfile)
            if currentProfile:
                queryPasswords(vaultPath(currentProfile))
        elif choice == "5":
            currentProfile = requireProfile(currentProfile)
            if currentProfile:
                listRecords(vaultPath(currentProfile))
        elif choice == "6":
            currentProfile = requireProfile(currentProfile)
            if currentProfile:
                editRecord(vaultPath(currentProfile))
        elif choice == "7":
            currentProfile = requireProfile(currentProfile)
            if currentProfile:
                deleteRecord(vaultPath(currentProfile))
        elif choice == "8":
            currentProfile = requireProfile(currentProfile)
            if currentProfile:
                exportBackup(vaultPath(currentProfile))
        elif choice == "9":
            currentProfile = requireProfile(currentProfile)
            if currentProfile:
                importBackup(vaultPath(currentProfile))
        elif choice == "10":
            currentProfile = requireProfile(currentProfile)
            if currentProfile:
                importCsv(vaultPath(currentProfile))
        elif choice == "11":
            newProfile = selectProfile()
            if newProfile:
                currentProfile = newProfile
        elif choice == "0":
            clearScreen()
            sys.exit(0)
        else:
            print("無效選項")


def parseArgs() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="本機多設定檔密碼管理程式")
    parser.add_argument(
        "--weak-check",
        action="store_true",
        help="設定主碼時啟用離線弱密碼檢查（不會連網查詢，僅本機規則比對）",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parseArgs()
    try:
        mainMenu(weakCheck=args.weak_check)
    except (KeyboardInterrupt, EOFError):
        clearScreen()
        sys.exit(0)
